# Lotö Yksinpuhelu — Blender r001

Ensimmäinen ajettava katselmusrevisio, 28.9.2026. Alkuperäinen Formula säilyy vertailussa; massat, ajofysiikka, renkaat ja asennetut tekniikkaosat säilyvät.

Mallipaja: `model-inspector.html?vehicle=formula&revision=blender-r001`. Valitse osa, merkitse pintaan ja paina **Tallenna katselmus**. Merkinnät tallentuvat yksityiseen katselmukseen kehittäjälle. JSON on varmuuskopio. Geometrian muutos vanhentaa pintapisteen, mutta huomion teksti säilyy.

`formula-r001.blend`: erillinen nokka, siivet, sivuponttoonit, moottorikate, avoin ohjaamo, turvakaari, ilmanotto, valot ja tekniikka. Piilotetussa kokoelmassa alkuperäinen vertailumalli. Metrit; pelin X vasemmalle, Y ylös, Z eteen vastaa Blenderin X, −Z, Y. Kiinnityssopimus `assembly-contract.json`.

Blenderin Scripting-tilassa voit suorittaa mukana olevan `review_tools.py`-tekstin kerran ja tuoda JSON-merkinnät. Se tarkistaa lähteen muutosleimat eikä käytä verkkoyhteyttä tai käynnistyskoodia. Käsimuokkaukset erilliseen tiedostoon; generaattori ei korvaa käsin muokattua lähdettä.

Nykyisten fyysisten osapaikkojen nimet säilyvät: ovi tarkoittaa Formulassa sivuponttoonia, katto turvakaarta ja takalasi moottorin ilmanottoa. Ajossa pyörät ja jousitus seuraavat oikeaa simulaatiota; Mallipajan tekniikka on paikallaan oleva katselmuskokoonpano.
