# VNQ Matalalento — Blender r001

Ensimmäinen ajettava katselmusrevisio, 28.9.2026. Alkuperäinen auto säilyy vertailussa. Korimallin valinta ei muuta ajofysiikkaa, massaa tai asennettujen tekniikkaosien ominaisuuksia.

0.5.11: yhteinen ovi-/lokasuojaprofiili, lasien alle jatkuva maalattu vyötärö, suljetut valosyvennykset ja puskurien kulmat sekä loiva keulan kavennus. Ohjaamon ja lasien muoto säilyy. Korjaukset jatkavat r001:tä.

Mallipaja: `model-inspector.html?vehicle=racer&revision=blender-r001`. Valitse osa, merkitse pintaan ja paina **Tallenna katselmus**. Merkinnät tallentuvat yksityisenä katselmuksena kehittäjän luettaviksi; JSON on vapaaehtoinen varmuuskopio. Muuttuneen geometrian vanha pintapiste ei muutu automaattisesti hyväksytyksi.

`racer-r001.blend` sisältää erilliset koripaneelit, rungon, kiinnikkeet ja tekniikan sekä piilotetun alkuperäisen vertailumallin. Blender käyttää metrejä; pelin X vasemmalle, Y ylös, Z eteen vastaa Blenderin X, −Z, Y. `assembly-contract.json` dokumentoi vastaanottajan akselit ja kiinnityspisteet.

Blenderin Scripting-tilassa voit suorittaa mukana olevan `review_tools.py`-tekstin kerran. Se tuo JSON-merkinnät ja tarkistaa lähteen muutosleimat. Ei automaattisesti suoritettavaa käynnistyskoodia tai verkkoyhteyksiä. Tallenna omat käsimuokkaukset erillisenä tiedostona; generaattori ei korvaa käsin muokattua lähdettä.

Tekniikan ja pyörien katselmusmallit ovat vertailua varten. Ajettavassa autossa käytetään asennettuja renkaita, vanteita, moottoria ja toimivaa animoitua jousitusta. Lokasuojat kuuluvat nykyisiin konepelti-/takaluukkupaikkoihin; tätä revisiota varten ei ole lisätty fyysisiä osapaikkoja.
