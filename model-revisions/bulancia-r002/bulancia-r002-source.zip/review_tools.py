"""TGRG local review helpers. Open this Text in Blender, press Run Script once.
No network, auto-run, startup-file changes or external dependencies.
"""
import bpy, json, math, re, uuid, hashlib, struct
from pathlib import Path
from mathutils import Vector, Matrix
from bpy.props import StringProperty, EnumProperty
from bpy_extras.io_utils import ImportHelper, ExportHelper

INVALID_HASH = 'sha256:' + '0' * 64

def game(v): return [float(v[0]), float(v[2]), float(-v[1])]
def blender(v): return Vector((v[0], -v[2], v[1]))
def owner(obj):
    while obj:
        if obj.get('partId') and obj.name.startswith('PART.'): return obj
        obj=obj.parent
    return None

def parts():
    revision=bpy.context.scene.get('revision','blender-r001')
    col=bpy.data.collections.get('01 BULANCIA '+revision.replace('blender-','')) if revision in ('blender-r001','blender-r002') else None
    return {o['partId']:o for o in col.objects if o.name.startswith('PART.') and o.get('partId')} if col else {}

def geometry_stamp(part):
    """Detect local authoring changes; browser SHA comes from the shipped GLB.
    This stamp is NOT claimed to be the browser geometry fingerprint.
    """
    digest=hashlib.sha256();graph=bpy.context.evaluated_depsgraph_get()
    for obj in sorted((o for o in part.children_recursive if o.type=='MESH'),key=lambda o:o.name):
        digest.update(obj.name.encode());evaluated=obj.evaluated_get(graph);mesh=evaluated.to_mesh();mesh.calc_loop_triangles()
        for row in obj.matrix_world:digest.update(struct.pack('<4f',*row))
        for tri in mesh.loop_triangles:
            for index in tri.vertices:digest.update(struct.pack('<3f',*mesh.vertices[index].co))
        evaluated.to_mesh_clear()
    return digest.hexdigest()

def finite(values,limit):
    return isinstance(values,list) and len(values)==3 and all(type(x) in (int,float) and math.isfinite(x) and abs(x)<=limit for x in values)

def read_report(path):
    path=Path(path)
    if path.stat().st_size>1_000_000:raise ValueError('JSON enintään 1 MB')
    data=json.loads(path.read_text(encoding='utf8'))
    return validate_report(data)

def validate_report(data):
    if not isinstance(data,dict) or data.get('format')!='tgrg.vehicle-inspection.v1' or data.get('vehicle')!='bulancia' or data.get('presentation')!=bpy.context.scene.get('revision','blender-r001') or data.get('presentation') not in ('blender-r001','blender-r002') or data.get('mountVersion')!=2:raise ValueError('Merkinnät kuuluvat eri Bulancia-revisioon kuin avoin Blender-malli')
    pins=data.get('pins');seen=set()
    if not isinstance(pins,list) or len(pins)>200:raise ValueError('Enintään 200 merkintää')
    for pin in pins:
        if not isinstance(pin,dict):raise ValueError('Virheellinen merkintä')
        for key,pattern in [('id',r'[\w-]{1,80}'),('part',r'[\w:-]{1,80}'),('hash',r'sha256:[a-f0-9]{64}')]:
            if not isinstance(pin.get(key),str) or not re.fullmatch(pattern,pin[key],re.ASCII):raise ValueError('Virheellinen tunnus')
        camera=pin.get('camera',{});note=pin.get('note')
        if pin['id'] in seen or not isinstance(note,str) or not note.strip() or len(note)>1000 or not finite(pin.get('point'),100) or not finite(pin.get('normal'),1) or abs(sum(x*x for x in pin['normal'])**.5-1)>.001 or not isinstance(camera,dict) or not finite(camera.get('position'),10000) or not finite(camera.get('target'),10000) or pin.get('kind','issue') not in ('issue','node','mount') or pin.get('status','open') not in ('open','done'):raise ValueError('Virheellinen merkintä')
        seen.add(pin['id'])
    return data

def make_pin(part,point,normal,note,kind='issue',pin=None):
    collection=bpy.data.collections.get('03 HUOMIOT JA SOLMUT')
    if not collection:
        collection=bpy.data.collections.new('03 HUOMIOT JA SOLMUT');bpy.context.scene.collection.children.link(collection)
    obj=bpy.data.objects.new('Huomio — '+note[:40],None);collection.objects.link(obj);obj.parent=part
    obj.matrix_parent_inverse=Matrix.Identity(4);obj.location=blender(point);obj.rotation_euler=blender(normal).to_track_quat('Z','Y').to_euler()
    obj.empty_display_type='ARROWS' if kind=='mount' else 'SPHERE';obj.empty_display_size=.055;obj.show_in_front=True
    obj['review_pin']=True;obj['markerId']=pin['id'] if pin else str(uuid.uuid4());obj['kind']=kind;obj['note']=note;obj['status']=pin.get('status','open') if pin else 'open';obj['partId']=part['partId'];obj['review_hash']=pin['hash'] if pin else part.get('review_hash',INVALID_HASH)
    obj['camera']=json.dumps(pin['camera']) if pin else json.dumps({'position':game(bpy.context.scene.camera.location),'target':[0,.32,0]})
    return obj

def import_report(data):
    by_id=parts();existing={o.get('markerId'):o for o in bpy.data.objects if o.get('review_pin')}
    if any(p['part'] not in by_id for p in data['pins']):raise ValueError('Merkinnän osaa ei löydy tästä mallista')
    if len(existing)+sum(json.dumps(p,sort_keys=True) not in {o.get('source_pin_json') for o in existing.values()} for p in data['pins'])>200:raise ValueError('Enintään 200 merkintää')
    created=[];sources={o.get('source_pin_json') for o in existing.values()}
    for pin in data['pins']:
        source=json.dumps(pin,sort_keys=True)
        if source in sources:continue
        if pin['id'] in existing:pin={**pin,'id':str(uuid.uuid4())} # Keep conflicting notes side by side.
        if len(existing)+len(created)>=200:raise ValueError('Enintään 200 merkintää')
        part=by_id[pin['part']];obj=make_pin(part,pin['point'],pin['normal'],pin['note'],pin.get('kind','issue'),pin)
        obj['stale']=pin['hash']!=part.get('review_hash') or geometry_stamp(part)!=part.get('authoring_stamp');obj.hide_viewport=bool(obj['stale']);obj['source_pin_json']=source;created.append(obj)
    return created

def export_report():
    data={'format':'tgrg.vehicle-inspection.v1','vehicle':'bulancia','presentation':bpy.context.scene.get('revision','blender-r001'),'mountVersion':2,'gameVersion':bpy.context.scene.get('game_version','0.5.2'),'pins':[]}
    stamps={}
    for obj in bpy.data.objects:
        if not obj.get('review_pin'):continue
        part=owner(obj.parent)
        if not part:raise ValueError('Merkinnältä puuttuu isäntäosa')
        local=part.matrix_world.inverted()@obj.matrix_world
        normal=local.to_3x3().inverted().transposed()@Vector((0,0,1));normal.normalize()
        if part.name not in stamps:stamps[part.name]=part.get('review_hash',INVALID_HASH) if geometry_stamp(part)==part.get('authoring_stamp') else INVALID_HASH
        stamp=stamps[part.name]
        data['pins'].append({'id':obj['markerId'],'part':part['partId'],'hash':obj.get('review_hash',stamp) if stamp!=INVALID_HASH else stamp,'note':obj['note'],'point':game(local.translation),'normal':game(normal),'camera':json.loads(obj['camera']),'kind':obj.get('kind','issue'),'status':obj.get('status','open')})
    return validate_report(data)

class TGRG_Add(bpy.types.Operator):
    bl_idname='tgrg.mark';bl_label='Merkitse 3D-kursorin kohta';bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        part=owner(context.active_object)
        if not part:self.report({'ERROR'},'Valitse ensin korin osa');return {'CANCELLED'}
        if sum(bool(o.get('review_pin')) for o in bpy.data.objects)>=200:self.report({'ERROR'},'Enintään 200 merkintää');return {'CANCELLED'}
        local=part.matrix_world.inverted()@context.scene.cursor.location
        normal=part.matrix_world.to_3x3().transposed()@(context.scene.cursor.rotation_euler.to_matrix()@Vector((0,0,1)))
        obj=make_pin(part,game(local),game(normal.normalized()),context.scene.tgrg_note.strip() or 'Tarkista tämä kohta',context.scene.tgrg_kind)
        for o in context.selected_objects:o.select_set(False)
        obj.select_set(True);context.view_layer.objects.active=obj;return {'FINISHED'}

class TGRG_Import(bpy.types.Operator,ImportHelper):
    bl_idname='tgrg.import_notes';bl_label='Avaa merkinnät JSON';bl_options={'REGISTER','UNDO'}
    filename_ext='.json'
    filter_glob:StringProperty(default='*.json',options={'HIDDEN'})
    def execute(self,context):
        try:
            added=import_report(read_report(self.filepath));stale=sum(bool(o.get('stale')) for o in added)
            self.report({'INFO'},f'{len(added)} uutta merkintää; {stale} vanhentunutta piilotettu');return {'FINISHED'}
        except (ValueError,OSError,KeyError,TypeError) as error:self.report({'ERROR'},str(error));return {'CANCELLED'}

class TGRG_Export(bpy.types.Operator,ExportHelper):
    bl_idname='tgrg.export_notes';bl_label='Tallenna merkinnät JSON'
    filename_ext='.json'
    filter_glob:StringProperty(default='*.json',options={'HIDDEN'})
    def execute(self,context):
        try:
            data=export_report();text=json.dumps(data,ensure_ascii=False,indent=2)+'\n'
            if len(text.encode())>1_000_000 or len(data['pins'])>200:raise ValueError('Merkintäpaketti on liian suuri')
            Path(self.filepath).write_text(text,encoding='utf8');return {'FINISHED'}
        except (ValueError,OSError,KeyError,TypeError) as error:self.report({'ERROR'},str(error));return {'CANCELLED'}

class TGRG_Panel(bpy.types.Panel):
    bl_label='Bulancia · mallikatselmus';bl_idname='TGRG_PT_review';bl_space_type='VIEW_3D';bl_region_type='UI';bl_category='TGRG'
    def draw(self,context):
        layout=self.layout;obj=context.active_object;part=owner(obj)
        layout.label(text=part.get('partName',part['partId']) if part else 'Valitse osa')
        layout.label(text='Shift + hiiren oikea: 3D-kursori',icon='CURSOR')
        layout.prop(context.scene,'tgrg_kind',text='Tyyppi');layout.prop(context.scene,'tgrg_note',text='Huomio');layout.operator('tgrg.mark')
        if obj and obj.get('review_pin'):
            box=layout.box();box.prop(obj,'["note"]',text='Teksti');box.prop(obj,'["status"]',text='open / done');box.label(text='G: siirrä · R: suunta · X: poista')
        layout.separator();layout.operator('tgrg.import_notes');layout.operator('tgrg.export_notes');layout.separator();layout.label(text='Uusi mallirevisio: Tallenna nimellä')

CLASSES=(TGRG_Add,TGRG_Import,TGRG_Export,TGRG_Panel)
def register():
    for old in reversed(bpy.app.driver_namespace.get('_tgrg_review_classes',())):
        if old.is_registered:bpy.utils.unregister_class(old)
    for cls in CLASSES:bpy.utils.register_class(cls)
    bpy.app.driver_namespace['_tgrg_review_classes']=CLASSES
    bpy.types.Scene.tgrg_note=StringProperty(name='Huomio',maxlen=1000,default='')
    bpy.types.Scene.tgrg_kind=EnumProperty(name='Tyyppi',items=[('issue','Huomio',''),('node','Solmupiste',''),('mount','Kiinnityspiste','')])
if __name__=='__main__':register()
