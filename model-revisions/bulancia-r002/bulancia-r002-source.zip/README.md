# Bulancia — Blender r002

Kahdeksan r001-katselmushavainnon korjaus: yhteiset korisaumat, tasainen takaluukku ja takasiipi, pyöreät pyöräaukot ja erilliset helmat, A-pilarin peilijalusta, vannekehät/keskiöt/jarrulevyt sekä rungon tekniikkatilat.

0.5.5 jatkaa käyttäjän pyynnöstä samaa r002-revisiota: sisäinen pyöräkotelo jää maalatun kaaren alle ja pakoputken suu tulee esiin takapuskurin oikeasta aukosta. Lisäksi kuuden uuden havainnon perusteella kyljessä on yhteinen jatkuva yläviiste ja pintaprofiili, päätypellit seuraavat konepellin/takaluukun kaarevuutta ja neljä sisälokasuojaa peittävät tekniikan. Helmat säilyvät ennallaan. Aiemmat r002-tiedostot ovat Git-historiassa. Muuttuneen osan vanha merkintä säilyy tekstinä mutta pintapiste vaatii uuden kohdistuksen; ennallaan olevien osien pisteet toimivat edelleen.

0.5.6 tuo korin peliin renderöintivaihtoehtona **Uusi kori · r002**. Pitkän oven jakopilari on nyt oven takareunassa, oven lasi yhtenäinen ja takana erillinen kiinteä sivulasi. Valinta löytyy Ulkonäkö-osiosta; alkuperäinen, Versio 2 ja Versio 3 säilyvät. Uusi asennus näyttää uuden korin oletuksena, aiemmin tallennettu vertailuvalinta säilyy.

## Tarkista selaimessa

0.5.10 jatkaa samaa r002:ta: perä nousee nyt loivasti käyttäjän uuden huomion mukaisesti, ja takavalojen aukot levenevät sisäänpäin. Pyöristetyt syvennykset rakentuvat yhtenäisistä pinnoista ilman päällekkäisiä reunoja. Uusi malli on ajettava; näkyvät jarrut ja jousitus käyttävät auton oikeita pyöräasentoja. Edellä kuvattu tasainen perä kuuluu aiemman revision historiaan.

https://alluharju-bot.github.io/ralli-play/model-inspector.html?revision=blender-r002

Valitse Bulancia-valikosta Alkuperäinen / Hiottu / Viimeistelty / Blender r001 / Blender r002. Kamera säilyy vaihdettaessa. **Tekniikka** näyttää rungon, moottorin, voimansiirron, ohjauksen, ripustukset, pakoputken, pyörät ja jarrut ilman ulkokuorta. **Näytä kaikki** palauttaa korin. Jokaisen osan voi edelleen valita, piilottaa ja eristää.

Merkitse huomiot kuten ennen ja paina **Tallenna katselmus**. Kirjautuminen on sama kuin pelissä. r001- ja r002-merkinnät ovat omissa tallennuksissaan; uuteen geometriaan ei kopioida vanhoja pisteitä vahvistettuina eikä käyttäjän havaintoja kuitata automaattisesti käsitellyiksi.

## Blender ja osasopimus

Avaa **Bulancia-r002.blend**. Osat: **01 BULANCIA r002**. Kiinnikkeet: **02 KIINNIKKEET**. **06 TEKNIIKAN TILAVARAUKSET** sisältää moottorin, vaihteiston, pakoputken ja kardaanin varatut tilat; kytke kokoelma näkyviin tarkastaaksesi ne. Alkuperäinen tehdasmalli on omassa piilotetussa vertailukokoelmassaan. r001 säilyy erillisenä alkuperäisenä tiedostona.

Työkalut: Scripting → `review_tools.py` → Run Script → 3D-näkymän N → TGRG. JSON-kierros käyttää avoimen Blender-mallin revisiota ja osatiivisteitä. Mallin muokkaus vanhentaa entisen pintapisteen. Tallenna käsin tehdyt jatkomuutokset uudella tiedostonimellä, esimerkiksi **Bulancia-r002-oma.blend**.

`assembly-contract.json` määrittää tämän keskikokoisen rungon vastaanottavat kiinnityspisteet, korisaumat, tekniikan tilat ja pyörätilan. Koordinaatit metreinä: peli X vasen / Y ylös / Z eteen; Blender X / -Z / Y. Luovuttajaosa ilmoittaa oman kiinnikkeensä; sovituksen määrää vastaanottava runko. Koemallin rajattu 0,90–1,10 visuaalinen skaalaus hylkää ylisuuren osan, ei muuta auton massaa tai fysiikkaa. Tarkistukset käyttävät todellista malligeometriaa.

Tässä toteutettu sopimus ohjaa r002:n mallinnusta ja sovituksen tarkistuksia. Se ei vielä siirrä ajettavan pelin kaikkia 23 autoa uusiin runkoperheisiin. Muut autot tarvitsevat oman kiinnitys- ja tilakuvauksensa. Pelin nykyinen osarekisteri säilyy: etulokasuojat/maski kuuluvat konepellin kokonaisuuteen, takakyljet/päätypelti takaluukkuun, kiinteät takasivulasit takalasin kokonaisuuteen ja helmat runkoon. Nämä eivät vielä ole erikseen ostettavia tai irtoavia osapaikkoja. Mallipajan tekniikka-, vanne- ja rengasmallit ovat edelleen rakenteen referenssi; peli käyttää valittuja tekniikkaosia, vanteita ja liikkuvia renkaita. Erilliset animoituvat ripustusvarret ja kaukaisuuden LOD-mallit ovat jatkotyötä. R001, alkuperäinen Bulancia ja nykyinen ajotuntuma säilyvät.

Lähde: `scripts/blender/build_bulancia_r002.py`, yhteiset mitat `bulancia_layout.py`, todellisen geometrian tarkistukset `test_bulancia_r002.py`. Ei ulkoisia tekstuureja tai uusia valonlähteitä. Mallin lukemat `revision.json`:ssä; koko kilpailun suorituskyky mitataan peliasennuksen yhteydessä.

Pelivienti: `scripts/blender/export_bulancia_game.py` lukee tämän Blender-lähteen ja tuottaa osakohtaisen `src/assets/bulancia-r002.json`-kirjaston. Julkaisu pakkaa sen sisältötiivisteellä nimetyiksi erikseen ladattaviksi osiksi. Mallipajan pyöräkeskuksen ja ajettavan vakiokorin välinen Y-siirtymä on −0,11 m; fysiikan kiinnikkeitä tai mittoja ei muuteta.
