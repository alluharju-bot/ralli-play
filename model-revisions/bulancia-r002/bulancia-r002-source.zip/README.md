# Bulancia — Blender r002

Kahdeksan r001-katselmushavainnon korjaus: yhteiset korisaumat, tasainen takaluukku ja takasiipi, pyöreät pyöräaukot ja erilliset helmat, A-pilarin peilijalusta, vannekehät/keskiöt/jarrulevyt sekä rungon tekniikkatilat.

0.5.5 jatkaa käyttäjän pyynnöstä samaa r002-revisiota: sisäinen pyöräkotelo jää maalatun kaaren alle ja pakoputken suu tulee esiin takapuskurin oikeasta aukosta. Lisäksi kuuden uuden havainnon perusteella kyljessä on yhteinen jatkuva yläviiste ja pintaprofiili, päätypellit seuraavat konepellin/takaluukun kaarevuutta ja neljä sisälokasuojaa peittävät tekniikan. Helmat säilyvät ennallaan. Aiemmat r002-tiedostot ovat Git-historiassa. Muuttuneen osan vanha merkintä säilyy tekstinä mutta pintapiste vaatii uuden kohdistuksen; ennallaan olevien osien pisteet toimivat edelleen.

## Tarkista selaimessa

https://alluharju-bot.github.io/ralli-play/model-inspector.html?revision=blender-r002

Valitse Bulancia-valikosta Alkuperäinen / Hiottu / Viimeistelty / Blender r001 / Blender r002. Kamera säilyy vaihdettaessa. **Tekniikka** näyttää rungon, moottorin, voimansiirron, ohjauksen, ripustukset, pakoputken, pyörät ja jarrut ilman ulkokuorta. **Näytä kaikki** palauttaa korin. Jokaisen osan voi edelleen valita, piilottaa ja eristää.

Merkitse huomiot kuten ennen ja paina **Tallenna katselmus**. Kirjautuminen on sama kuin pelissä. r001- ja r002-merkinnät ovat omissa tallennuksissaan; uuteen geometriaan ei kopioida vanhoja pisteitä vahvistettuina eikä käyttäjän havaintoja kuitata automaattisesti käsitellyiksi.

## Blender ja osasopimus

Avaa **Bulancia-r002.blend**. Osat: **01 BULANCIA r002**. Kiinnikkeet: **02 KIINNIKKEET**. **06 TEKNIIKAN TILAVARAUKSET** sisältää moottorin, vaihteiston, pakoputken ja kardaanin varatut tilat; kytke kokoelma näkyviin tarkastaaksesi ne. Alkuperäinen tehdasmalli on omassa piilotetussa vertailukokoelmassaan. r001 säilyy erillisenä alkuperäisenä tiedostona.

Työkalut: Scripting → `review_tools.py` → Run Script → 3D-näkymän N → TGRG. JSON-kierros käyttää avoimen Blender-mallin revisiota ja osatiivisteitä. Mallin muokkaus vanhentaa entisen pintapisteen. Tallenna käsin tehdyt jatkomuutokset uudella tiedostonimellä, esimerkiksi **Bulancia-r003.blend**.

`assembly-contract.json` määrittää tämän keskikokoisen rungon vastaanottavat kiinnityspisteet, korisaumat, tekniikan tilat ja pyörätilan. Koordinaatit metreinä: peli X vasen / Y ylös / Z eteen; Blender X / -Z / Y. Luovuttajaosa ilmoittaa oman kiinnikkeensä; sovituksen määrää vastaanottava runko. Koemallin rajattu 0,90–1,10 visuaalinen skaalaus hylkää ylisuuren osan, ei muuta auton massaa tai fysiikkaa. Tarkistukset käyttävät todellista malligeometriaa.

Tässä toteutettu sopimus ohjaa r002:n mallinnusta ja sovituksen tarkistuksia. Se ei vielä siirrä ajettavan pelin kaikkia 23 autoa uusiin runkoperheisiin. Muut autot tarvitsevat oman kiinnitys- ja tilakuvauksensa. Myös uudet lokasuojat, ripustusten näkyvät osat ja helmat tarvitsevat erillisen peliasennuksen, vaurio-/LOD-/UV-kierroksen ennen ajettavan auton vaihtamista. R001, alkuperäinen Bulancia ja nykyinen ajotuntuma säilyvät.

Lähde: `scripts/blender/build_bulancia_r002.py`, yhteiset mitat `bulancia_layout.py`, todellisen geometrian tarkistukset `test_bulancia_r002.py`. Ei ulkoisia tekstuureja tai uusia valonlähteitä. Mallin lukemat `revision.json`:ssä; koko kilpailun suorituskyky mitataan peliasennuksen yhteydessä.
