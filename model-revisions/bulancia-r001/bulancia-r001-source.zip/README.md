# Bulancia — Blender r001

Ensimmäinen muotoilu- ja rakennekatselmus. Käyttäjän 27.9.2026 Bulancia-kuva ohjaa pyöränkaarien, tummien helmamuotojen, lasikehysten ja etuvalojen muotokieltä. Matalalennon kuva on saman tyyliperheen seuraava vertailukohta. Tämä ei vielä ole kuvan materiaali-/detaljitasoa eikä ajettavan auton korvaava malli.

## Tarkista selaimessa

https://alluharju-bot.github.io/ralli-play/model-inspector.html?revision=blender-r001

Valitse vasemmalta Alkuperäinen / Hiottu / Viimeistelty / Blender r001. Kamera pysyy samassa kohdassa. Valitse osa autosta tai listalta. Piilota / Eristä / Näytä kaikki auttavat liitosten katsomisessa.

Valitse Huomio, Solmupiste tai Kiinnityspiste → Merkitse pintaan → napsauta mallia → kirjoita lyhyt teksti → Lisää merkintä. Merkinnät säilyvät tässä selaimessa; **Tallenna JSON** tekee jaettavan kopion. ✓ merkitsee huomion käsitellyksi, ↶ avaa uudelleen. Muuttuneen osan vanha merkintä säilyy listassa varoituksena eikä näy vahvistettuna pintapisteenä.

## Avaa Blenderissä

1. Avaa **Bulancia-r001.blend** (testattu Blender 5.2.2 LTS).
2. Osat ovat kokoelmassa **01 BULANCIA r001**. Valitse oikea mesh ja muokkaa sitä Blenderin normaaleilla työkaluilla. Osan `PART.*`-isäntä säilyttää pysyvän `partId`:n ja origon.
3. Alkuperäinen vertailumalli on piilotettuna kokoelmassa **04 ALKUPERAINEN — vertailu**. Kytke näkyvyydet Outlinerissa. Se on tehdasmallin geometrinen tilannekuva yksinkertaistetuilla materiaaleilla, ei identtinen pelin shader-esitys.
4. Tallenna oma työsi **Save As → Bulancia-r002.blend**. Älä generoi käsin muokattua tiedostoa uudelleen.

### Merkinnät Blenderissä

**Scripting** → tekstiluettelosta **review_tools.py** → **Run Script** kerran. Palaa Layoutiin → **N** → **TGRG**. Työkalu ei asennu käynnistystiedostoon eikä suoritu itsestään tiedoston avauksessa.

- Avaa selaimessa tehty JSON **Avaa merkinnät JSON** -napilla.
- Valitse osa, aseta 3D-kursori sen pinnalle **Shift + hiiren oikea painike**, valitse tyyppi ja kirjoita huomio → **Merkitse 3D-kursorin kohta**.
- Merkintä on Empty: **G** siirtää, **R** muuttaa sen suuntaa, **X** poistaa. Kiinnityspisteen paikallinen Z osoittaa pinnasta ulos; tarkista suunta sivulta.
- Valitun merkinnän teksti ja `open` / `done` ovat TGRG-paneelissa.
- **Tallenna merkinnät JSON** palauttaa merkinnät Mallipajaan. Uusi tai siirretty merkintä palautuu vain vastaavan muuttumattoman osan pinnalle.
- Jos osan geometria/asennus muuttuu Blenderissä, palautetut merkinnät merkitään selaimessa vanhentuneiksi. Uusi malli pitää viedä ja katselmoida uutena revisiona. JSON ei muuta pelin fyysisiä kiinnikkeitä.

## Rakenne ja rajat

Konepelti, katto, takaluukku, ovet, lasit, lokasuojat, helmat, maski, puskurit, peilit, valot, vilkut ja pyörät ovat erillisiä katselmoitavia osia. Runko sisältää lattian, runkopalkit, pilarit ja kojelaudan/rattihahmotelman. Moottori, istuimet ja pakoputki ovat nykyisestä tehdasmallista siirrettyjä paikkavarauksia. Kiinnikkeitä ja saumapisteitä on nimetty erikseen. Ne ovat tarkistettavia luonnoksia, eivät valmiiksi hyväksytty mekaniikan järjestelmä.

Metrit. Peli: X vasen, Y ylös, Z keula. Blender: X sama, Z ylös, -Y keula. Kiinnityspisteet tallentuvat oman osansa koordinaatteihin. `partId` on pysyvä osan tunnus. `gameSlot` kertoo mahdollisen nykyisen pelipaikan; esimerkiksi helman `frame` ei luo peliin uutta irtoavaa helmapeltiä.

Budjetti: enintään 22 000 kolmiota ja 100 osa–materiaali-piirtoerää. 9 materiaalia, ei ulkoisia tekstuureja. Tarkat luvut `revision.json`:ssä / Mallipajassa. Luvut eivät sisällä kilpailun varjopasseja, muita autoja tai efektejä, eivätkä ole FPS-lupaus. Varsinainen ajettava asennus, törmäysmuodot, lommojen tiheys, osien vaihtelu, pintakuvioiden UV:t ja kaukomalli tarvitsevat oman integraatiokierroksensa.

## Toistettava kehittäjän lähde

Repon `scripts/export-bulancia-reference.mjs` tallentaa alkuperäisen mallin GLB:n ja mitat paikallisesta Mallipajasta. `scripts/blender/build_bulancia.py` muodostaa revision geometrian ja renderit. Olemassa olevan generoidun tiedoston korvaaminen vaatii `-- --replace-generated`; käytä vain, kun tiedostossa ei ole käsimuokkauksia.

`check-bulancia-review.mjs` tallentaa GLB:n todelliset selaimessa lasketut osatiivisteet. `finalize_bulancia.py` sitoo ne vain generoituun lähdemalliin. `test_review_tools.py` testaa selaimesta viedyn merkinnän kierroksen, koordinaatit, pinnan muuttumisen ja virheellisen tuonnin. Tekstuurit ja käyttäjän alkuperäiset referenssikuvat eivät sisälly ladattavaan pakettiin.
